package main

import (
	"fmt"
)

func sudahAda(DaftarTeman []string, nama string) bool {
	for _, teman := range DaftarTeman {
		if teman == nama {
			return true
		}
	}
	return false
}

func main() {
	DaftarTeman := []string{"Andi", "Budi", "Cici"}

	namaBaru := []string{"Dewi", "Budi", "Eka"}

	for _, nama := range namaBaru {
		if !sudahAda(DaftarTeman, nama) {
			DaftarTeman = append(DaftarTeman, nama)
		} else {
			fmt.Println("Nama", nama, "sudah ada dalam daftar.")
		}
	}

	fmt.Println("Daftar Teman:", DaftarTeman)
}