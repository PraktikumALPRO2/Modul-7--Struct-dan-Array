package main
import "fmt"


func main() {
	HARGABUAH := map[string]int{
		"Apel":   5000,
		"Pisang": 3000,
		"Mangga": 7000,
	}

	fmt.Println("Harga Buah:")
	for buah, harga := range HARGABUAH {
		fmt.Printf("%s: Rp%d\n", buah, harga)
	}

	fmt.Print("Harga buah Mangga = ", HARGABUAH["Mangga"])
}