package main

import (
	"fmt"
)

func main() {
	var ClubA, ClubB string
	var skorA, skorB int
	var PEMENANG []string

	fmt.Print("Masukkan nama Klub A: ")
	fmt.Scanln(&ClubA)
	fmt.Print("Masukkan nama Klub B: ")
	fmt.Scanln(&ClubB)

	fmt.Println("\nMasukkan skor pertandingan (masukkan skor negatif untuk menghentikan):")
	for i := 1; ; i++ {
		fmt.Printf("Pertandingan %d - Skor %s: ", i, ClubA)
		fmt.Scan(&skorA)
		fmt.Printf("Pertandingan %d - Skor %s: ", i, ClubB)
		fmt.Scan(&skorB)

		if skorA < 0 || skorB < 0 {
			break
		}

		if skorA > skorB {
			PEMENANG = append(PEMENANG, ClubA)
		} else if skorB > skorA {
			PEMENANG = append(PEMENANG, ClubB)
		} else {
			PEMENANG = append(PEMENANG, "Draw")
		}
	}

	fmt.Println("\nHasil pertandingan:")
	for i, hasil := range PEMENANG {
		fmt.Printf("Pertandingan %d: %s\n", i+1, hasil)
	}
}
